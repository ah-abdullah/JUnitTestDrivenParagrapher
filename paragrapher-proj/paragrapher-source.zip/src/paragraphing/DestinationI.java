package paragraphing;

public interface DestinationI {

	void addLines( String[] lines ) ;
}
