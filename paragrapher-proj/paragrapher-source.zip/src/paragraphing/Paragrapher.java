/**
 * 
 */
package paragraphing;


/**
 * @author XYZ
 *
 */
public class Paragrapher implements ParagrapherI {
	DestinationI destination ;
	

	public Paragrapher(DestinationI dest) {
		destination = dest ;
	}

	/** 
	 * @see paragraphing.ParagrapherI#setWidth(int)
	 */
	@Override
	public void setWidth(int width) {
		// TODO Auto-generated method stub

	}

	/**
	 * @see paragraphing.ParagrapherI#addWord(java.lang.String[])
	 */
	@Override
	public void addWord(String[] parts) {
		// TODO Auto-generated method stub

	}

	/**
	 * @see paragraphing.ParagrapherI#addWord(java.lang.String)
	 */
	@Override
	public void addWord(String word) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see paragraphing.ParagrapherI#ship()
	 */
	@Override
	public void ship() {
		// TODO Auto-generated method stub

	}

}
